// C:\Users\shyam\Downloads\blog-react\src\Pages\Auth\Login.jsx

import { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

import {
  FaEnvelope,
  FaLock,
  FaEye,
  FaEyeSlash,
  FaSync,
} from "react-icons/fa";

import "./Login.css";

// ==========================================
// ✅ CHANGE 1: DYNAMIC API URL
// ==========================================

const API_URL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    ? "http://127.0.0.1:8000"
    : "http://192.168.29.233:8000";

const Login = () => {
  const navigate = useNavigate();

  const [showPassword, setShowPassword] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [captchaInput, setCaptchaInput] = useState("");
  const [captcha, setCaptcha] = useState("");

  const [captchaError, setCaptchaError] = useState("");
  const [formError, setFormError] = useState("");

  const [loading, setLoading] = useState(false);

  const canvasRef = useRef(null);


  // ==========================================
  // GENERATE CAPTCHA
  // ==========================================

  const generateCaptcha = () => {
    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    let result = "";

    for (let i = 0; i < 6; i++) {
      result += chars.charAt(
        Math.floor(Math.random() * chars.length)
      );
    }

    setCaptcha(result);
    setCaptchaInput("");
    setCaptchaError("");

    drawCaptcha(result);
  };


  // ==========================================
  // DRAW CAPTCHA
  // ==========================================

  const drawCaptcha = (text) => {
    const canvas = canvasRef.current;

    if (!canvas) return;

    const ctx = canvas.getContext("2d");

    // Background
    ctx.fillStyle = "#f1f5f9";
    ctx.fillRect(
      0,
      0,
      canvas.width,
      canvas.height
    );


    // Noise lines
    for (let i = 0; i < 8; i++) {
      ctx.beginPath();

      ctx.moveTo(
        Math.random() * canvas.width,
        Math.random() * canvas.height
      );

      ctx.lineTo(
        Math.random() * canvas.width,
        Math.random() * canvas.height
      );

      ctx.strokeStyle =
        `rgba(37, 99, 235, ${Math.random() * 0.3})`;

      ctx.lineWidth = 1.5;

      ctx.stroke();
    }


    // Noise dots
    for (let i = 0; i < 50; i++) {
      ctx.fillStyle =
        `rgba(37, 99, 235, ${Math.random() * 0.2})`;

      ctx.beginPath();

      ctx.arc(
        Math.random() * canvas.width,
        Math.random() * canvas.height,
        Math.random() * 2 + 1,
        0,
        Math.PI * 2
      );

      ctx.fill();
    }


    // CAPTCHA text
    ctx.font = "bold 28px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";


    for (let i = 0; i < text.length; i++) {
      const x = 25 + i * 28;

      const y =
        28 + (Math.random() - 0.5) * 8;

      const rotation =
        (Math.random() - 0.5) * 0.4;


      ctx.save();

      ctx.translate(x, y);
      ctx.rotate(rotation);


      const colors = [
        "#2563eb",
        "#4f46e5",
        "#7c3aed",
        "#0b1a33",
        "#1e293b",
      ];

      ctx.fillStyle =
        colors[
          Math.floor(
            Math.random() * colors.length
          )
        ];


      ctx.fillText(
        text[i],
        0,
        0
      );

      ctx.restore();
    }
  };


  // ==========================================
  // INITIAL CAPTCHA
  // ==========================================

  useEffect(() => {
    generateCaptcha();
  }, []);


  // ==========================================
  // LOGIN - ✅ CHANGE 2: withCredentials
  // ==========================================

  const handleSubmit = async (e) => {
    e.preventDefault();

    setFormError("");
    setCaptchaError("");


    // ------------------------------------------
    // CAPTCHA VALIDATION
    // ------------------------------------------

    if (captchaInput !== captcha) {
      setCaptchaError(
        "Invalid CAPTCHA. Please try again."
      );

      generateCaptcha();

      return;
    }


    // ------------------------------------------
    // START LOADING
    // ------------------------------------------

    setLoading(true);


    try {
      // ----------------------------------------
      // ✅ FASTAPI LOGIN - DYNAMIC URL
      // ----------------------------------------

      const response = await axios.post(
        `${API_URL}/auth/login`,  // ✅ CHANGE: Dynamic URL
        {
          email: email,
          password: password,
        },
        {
          withCredentials: true,  // ✅ CHANGE: Cookies ke liye
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );


      // ----------------------------------------
      // GET LOGIN RESPONSE
      // ----------------------------------------

      const data = response.data;


      // ----------------------------------------
      // SAVE JWT TOKEN
      // ----------------------------------------

      if (data.access_token) {
        localStorage.setItem(
          "access_token",
          data.access_token
        );
      }


      // ----------------------------------------
      // SAVE USER DATA
      // ----------------------------------------

      if (data.user) {
        localStorage.setItem(
          "user",
          JSON.stringify(data.user)
        );
      }


      console.log(
        "Login successful:",
        data
      );


      // ----------------------------------------
      // REDIRECT
      // ----------------------------------------

      if (data.user?.role === "admin") {
        navigate("/admin");
      } else {
        navigate("/user");
      }

    } catch (error) {

      console.error(
        "Login error:",
        error
      );


      // ----------------------------------------
      // FASTAPI ERROR
      // ----------------------------------------

      if (
        error.response &&
        error.response.data
      ) {
        setFormError(
          error.response.data.detail ||
          "Invalid email or password."
        );
      } else {
        setFormError(
          "Unable to connect to server. Please try again."
        );
      }

    } finally {
      setLoading(false);
    }
  };


  // ==========================================
  // JSX (NO CHANGES HERE)
  // ==========================================

  return (
    <div className="auth-page login-page">

      <div className="auth-container">

        {/* Back to Home */}

        <Link
          to="/"
          className="auth-back"
        >
          ← Back to Home
        </Link>


        <div className="auth-card">

          {/* Header */}

          <div className="auth-header">

            <h1>
              Welcome Back
            </h1>

            <p>
              Sign in to continue reading and publishing
            </p>

          </div>


          {/* FORM */}

          <form
            onSubmit={handleSubmit}
            className="auth-form"
          >

            {/* EMAIL */}

            <div className="form-group">

              <label>
                Email Address
              </label>

              <div className="input-wrapper">

                <FaEnvelope
                  className="input-icon"
                />

                <input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) =>
                    setEmail(e.target.value)
                  }
                  required
                />

              </div>

            </div>


            {/* PASSWORD */}

            <div className="form-group">

              <label>
                Password
              </label>

              <div className="input-wrapper">

                <FaLock
                  className="input-icon"
                />

                <input
                  type={
                    showPassword
                      ? "text"
                      : "password"
                  }
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) =>
                    setPassword(e.target.value)
                  }
                  required
                />


                <button
                  type="button"
                  className="password-toggle"
                  onClick={() =>
                    setShowPassword(
                      !showPassword
                    )
                  }
                >
                  {showPassword ? (
                    <FaEyeSlash />
                  ) : (
                    <FaEye />
                  )}
                </button>

              </div>

            </div>


            {/* CAPTCHA */}

            <div className="form-group captcha-group">

              <label>
                Enter the code below
              </label>


              <div className="captcha-wrapper">

                <canvas
                  ref={canvasRef}
                  width="180"
                  height="56"
                  className="captcha-canvas"
                />


                <button
                  type="button"
                  className="captcha-refresh"
                  onClick={generateCaptcha}
                  title="Refresh CAPTCHA"
                >
                  <FaSync />
                </button>

              </div>


              <div className="input-wrapper captcha-input-wrapper">

                <input
                  type="text"
                  placeholder="Enter CAPTCHA code"
                  value={captchaInput}
                  onChange={(e) =>
                    setCaptchaInput(
                      e.target.value
                    )
                  }
                  maxLength={6}
                  required
                />

              </div>


              {captchaError && (
                <span className="captcha-error">
                  {captchaError}
                </span>
              )}

            </div>


            {/* FORM OPTIONS */}

            <div className="form-options">

              <label className="remember-me">

                <input
                  type="checkbox"
                />

                Remember me

              </label>


              <Link
                to="/forgot-password"
                className="forgot-link"
              >
                Forgot password?
              </Link>

            </div>


            {/* FORM ERROR */}

            {formError && (
              <span className="form-error">
                {formError}
              </span>
            )}


            {/* LOGIN BUTTON */}

            <button
              type="submit"
              className="auth-btn"
              disabled={loading}
            >

              {loading
                ? "Signing In..."
                : "Sign In"}

            </button>

          </form>


          {/* FOOTER */}

          <div className="auth-footer">

            <p>

              Don't have an account?{" "}

              <Link
                to="/register"
                className="auth-link"
              >
                Create one now
              </Link>

            </p>

          </div>

        </div>

      </div>

    </div>
  );
};


export default Login;